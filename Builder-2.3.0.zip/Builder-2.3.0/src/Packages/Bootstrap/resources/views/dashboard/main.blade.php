@extends('dashboard')

@section('content')

    <h1>Dashboard</h1>

@stop