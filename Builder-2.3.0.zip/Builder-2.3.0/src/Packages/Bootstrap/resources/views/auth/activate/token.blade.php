@extends('layouts.master')

@section('app-content')

    <div class="row">
        <div class="col-md-4 col-md-offset-4 text-center">

            <h1 class="text-center">Activate</h1>

            <p>A new token has been emailed to you.</p>
        </div>
    </div>

@stop

