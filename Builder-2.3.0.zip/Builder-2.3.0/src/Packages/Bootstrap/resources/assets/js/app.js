$(function(){

    $('.alert').delay(7000).fadeOut();

});