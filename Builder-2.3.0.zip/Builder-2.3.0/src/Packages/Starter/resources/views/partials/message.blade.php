<div class="">
    {{ Session::get('message') }}
</div>