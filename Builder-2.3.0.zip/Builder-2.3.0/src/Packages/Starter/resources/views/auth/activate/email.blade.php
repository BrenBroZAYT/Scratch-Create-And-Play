    <h1>Activate</h1>

    <p>Please check your email to activate your account.</p>

    <a href="{{ url('activate/send-token') }}">Request new Token</a>

