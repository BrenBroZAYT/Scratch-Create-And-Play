    <h1>Activate</h1>

    <p>A new token has been emailed to you.</p>

