<div class="ui secondary vertical menu nav">
    <a class="item" href="{!! url('dashboard') !!}"><span class="fa fa-dashboard"></span> Dashboard</a>
    <a class="item" href="{!! url('user/settings') !!}"><span class="fa fa-user"></span> Settings</a>
    <a class="item" href="{!! url('teams') !!}"><span class="fa fa-users"></span> Teams</a>
    <div class="header item text-center">Admin</div>
    <a class="item" href="{!! url('admin/dashboard') !!}"><span class="fa fa-dashboard"></span> Dashboard</a>
    <a class="item" href="{!! url('admin/users') !!}"><span class="fa fa-users"></span> Users</a>
    <a class="item" href="{!! url('admin/roles') !!}"><span class="fa fa-lock"></span> Roles</a>
</div>